<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class todos extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Existing data to seed into the database
        // $data = [
        //     ['user_id' => '1', 'title' => 'drink water', 'body' => 'drink water at 9am', 'category' => 'life'],
        //     ['user_id' => '2', 'title' => 'sleep', 'body' => 'sleep at 9pm', 'category' => 'life'],
        //     ['user_id' => '3', 'title' => 'migration', 'body' => 'mass upload of accounts data', 'category' => 'work'],
        //     ['user_id' => '4', 'title' => 'meeting', 'body' => 'meeting at 5pm', 'category' => 'work'],
        //     // Add more data as needed
        // ];

        // Insert data into the database
        // foreach ($data as $item) {
        //     Todo::create($item);
        // }
    }
}
